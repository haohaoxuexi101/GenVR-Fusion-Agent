# GenVR-Fusion：面向聚变堆深穿透屏蔽的生成式稀有事件输运探索环境

参赛队伍：小手震  
成员：沈绍宁（清华大学）

GenVR-Fusion 面向开放探索赛题。它把一次数值输运异常从“看图怀疑”变成可执行的科学闭环：DeepSeek 根据真实 GMC 环境反馈提出下一步实验，环境执行后返回 CFM、Exact-MC 与固定 Dense 参照指标，完整记录 API 交换、工具调用和科学结论。

**核心结论**（限定在预声明的二维非均匀 lattice、给定检查点、样本预算与种子上）：在同为 128 个界面状态的预算下，把状态分配给角向离散比只增加面位置节点的 CFM 射线指标低 **43.5%**；联合加密使局部 Exact-MC 相对固定 Dense 参考的射线指标较粗网格降低 **57.3%**，但联合加密后的 CFM 相对其 Exact-MC 仍有 **5.0%** 归一化 L1 误差。离散化加密能缓解伪影，但学习响应算子的残差仍是下一步要处理的机制。

**这些结论去哪看证据（评委直达）**：

- **官方消融结论（43.5% / 57.3% / 5.0%）** → [`submission/runs/official_llm/`](submission/runs/official_llm/summary.json:1)：结论总表在 `summary.json` / `summary.md`；指标最好的角向实验（128 状态）在 [`experiments/angular_refined/`](submission/runs/official_llm/experiments/angular_refined/metrics.json:1)，局部 Exact-MC 最优的联合加密实验在 `experiments/combined_refined/`；全部实验对比图见 `ablation_summary.png`。
- **开放探索中 LLM 认为较好的结果** → 最新一次 `submission/runs/<UTC时间戳>_open_explore_*/`：最优配置写在 `summary.json` 的 **`best_config`** 字段（含 `n_pos/n_mu/n_phi`、`ray_index` 与相对基线变化），对应实验产物在 `experiments/<best_config 的 experiment_id>/`，全部提议与推理在 `trajectory.jsonl` 的 `llm_exchange`/`decision` 事件，对比图 `ablation_summary.png`。仓库内现有实例：[`submission/runs/20260903T031251Z_open_explore_demo/`](submission/runs/20260903T031251Z_open_explore_demo/summary.json:1)（24×24 演示；112×112 正式探索结构相同）。
- **换模型复核的运行** → 目录名带模型后缀（如 `…_official_llm_lattice_112_deepseek-v4-pro`），结论读取方式同上。

---

## 一、快速开始（三步）

**Windows PowerShell —— 逐条复制粘贴即可：**

```powershell
.\scripts\setup_env.ps1
.\scripts\smoke_test.ps1
.\scripts\reproduce_core.ps1
```

**Linux/macOS —— 逐条复制粘贴即可：**

```bash
bash scripts/setup_env.sh
bash scripts/smoke_test.sh
bash scripts/reproduce_core.sh
```

第 1 条自动创建环境；第 2 条离线冒烟，不需要任何密钥；第 3 条官方复现，首次运行会**交互式提示粘贴密钥**（隐藏回显、不落盘），粘贴后回车即可，无需编辑任何文件。若只想快速看 LLM 闭环，用 `.\scripts\demo_one_minute.ps1`（bash 对应 `bash scripts/demo_one_minute.sh`）替代第 3 条。

---

## 二、环境准备

**前置要求**：conda（Miniconda 即可）；GPU 可选（无 GPU 自动退 CPU，冒烟与演示仍可运行）。

```powershell
.\scripts\setup_env.ps1          # PowerShell
```
```bash
bash scripts/setup_env.sh        # Linux/macOS
```

[`setup_env.ps1`](scripts/setup_env.ps1) / [`setup_env.sh`](scripts/setup_env.sh) 的行为：

1. 自动探测 conda：PATH → 常见安装目录（`%ProgramData%`、`~/anaconda3|miniconda3`、`/opt/...`）；
2. 检测到 NVIDIA GPU → 用 [`environment.yml`](environment.yml)（PyTorch CUDA 12.8）；否则用 [`environment_cpu.yml`](environment_cpu.yml)（CPU 版）；
3. 环境已存在则自动更新，不存在则创建；环境名默认取 `environment.yml` 的 `name` 字段（`ssn`）；
4. 完成后自动运行 [`00_check_environment.py`](scripts/00_check_environment.py) 自检。

**参数覆盖**：conda 位置 `-CondaExe <路径>`（bash：`CONDA_EXE`）；环境名 `-EnvName <名>`（bash：`RAY_AGENT_ENV`）。

可选单元测试（复制粘贴即可；环境名由 `environment.yml` 固定为 `ssn`）：

```powershell
conda run -n ssn python -m pytest -q
```

---

## 三、四种运行模式

### 模式 A：离线冒烟（无密钥，验证环境可用）

```powershell
.\scripts\smoke_test.ps1          # 或 bash scripts/smoke_test.sh
```

causal 策略 + 24×24 小网格，**不需要 DeepSeek API key**。只验证闭环、JSONL 日志与产物格式，不用于支持科学结论。结果写入 `submission/runs/<UTC时间戳>_smoke/`。

### 模式 B：官方消融复现（可复现的因果证据）

```powershell
.\scripts\reproduce_core.ps1      # 等价于 .\scripts\reproduce_core_llm.ps1
```
```bash
bash scripts/reproduce_core.sh
```

首次运行会提示粘贴密钥（隐藏回显），其余无需任何修改。

112×112 网格，预声明 4 实验消融（coarse/position/angular/combined）+ 3 组随机参照。固定种子 260827、每实验采样预算 1000、固定 Dense 参照。**注意**：4 个实验全部执行，LLM 决定其顺序——这是为保证因果证据可复现的设计，探索性由模式 C 承担。结果写入 `submission/runs/<UTC时间戳>_official_llm_lattice_112[/_<model>]/`，与官方目录 [`submission/runs/official_llm/`](submission/runs/official_llm/run_manifest.json:1) 结构一致。

只重建派生总结（不改动原始实验输出）：

```bash
conda run -n ssn python scripts/refinalize_ray_run.py --run-dir submission/runs/official_llm
```

### 模式 C：开放探索（LLM 自主提议新实验）

```powershell
.\scripts\explore_open.ps1        # 112×112：512 状态预算、最多 5 次提议 + 2 组随机参照
.\scripts\explore_open.ps1 -Config configs/ray_agent_open_explore_demo.json   # 24×24 快速演示
```
```bash
bash scripts/explore_open.sh
EXPLORE_CONFIG=configs/ray_agent_open_explore_demo.json bash scripts/explore_open.sh
```

与模式 B 的本质区别：LLM **不是给固定实验排序，而是在声明边界内自由提议新实验**（[`run_open_exploration.py`](scripts/run_open_exploration.py:1) + [`open_policy.py`](ray_agent/open_policy.py:1)）。

- **固定**：环境、检查点、种子、采样预算、Dense 参照，以及搜索边界（配置的 `open_search` 段：`n_pos∈{1,2,4}`、`n_mu∈{2,4}`、`n_phi∈{8,16,32,64}`、总状态 ≤ 512）；
- **可探索**：LLM 每轮返回 JSON 提议 `{n_pos, n_mu, n_phi, hypothesis, decision_reason}`；越界/超预算/重复提议被拒绝，拒绝理由作为反馈送回重提（每轮最多 3 次）；
- **选策略**：结束后 `summary.json` 给出 `best_config`（最优配置及其相对基线的射线指数变化）与随机参照对比，`ablation_summary.png` 可视化。

### 模式 D：模型矩阵验证（可选）

```powershell
.\scripts\validate_deepseek_models.ps1                 # 默认验证 flash + pro
.\scripts\validate_deepseek_models.ps1 -Models "deepseek-v4-pro"   # 只验证指定模型
```
```bash
bash scripts/validate_deepseek_models.sh
DEEPSEEK_MODELS="deepseek-v4-pro" bash scripts/validate_deepseek_models.sh
```

调用 `/models` 检查可用模型，再对每个模型各做一次白名单决策，结果写入 [`submission/api_validation/deepseek_model_matrix.json`](submission/api_validation/deepseek_model_matrix.json:1)。

---

## 四、DeepSeek API Key 的提供方式

需要 API 的脚本（模式 B/C/D 与 [`demo_one_minute`](scripts/demo_one_minute.ps1)）会**自动**取得密钥，三种方式任选其一：

**方式 1（推荐，零文件编辑）：直接运行脚本，在提示处粘贴密钥**

脚本会显示 `DeepSeek API key (input is hidden):`，粘贴密钥后回车即可；隐藏回显、不落盘、进程结束后清除。命令本身就是第二节/第三节中的复制粘贴块，无需任何修改。

**方式 2：环境变量**（把 `sk-xxxx` 替换成你的密钥）：

```powershell
# PowerShell
$env:DEEPSEEK_API_KEY = "sk-xxxx"
```
```bash
# Linux/macOS
export DEEPSEEK_API_KEY="sk-xxxx"
```

**方式 3：仓库根目录 `.env` 文件**（脚本自动加载；已被 [`.gitignore`](.gitignore) 排除，绝不会进入提交包）。复制下面两行到 `.env`，把 `sk-xxxx` 替换成你的密钥（其余行可选，见 [`.env.example`](.env.example)）：

```text
DEEPSEEK_API_KEY=sk-xxxx
DEEPSEEK_MODEL=deepseek-v4-flash
```

**获取方式**：登录 [https://platform.deepseek.com](https://platform.deepseek.com) → 「API Keys」→ 创建并复制。任何曾在聊天、截图或终端历史中明文出现过的密钥都应视为已暴露，请在控制台撤销并重新生成。

安全保证：密钥不进入配置、manifest、命令、日志或错误消息；日志只保存公开消息、usage、response ID 与 system fingerprint；正式配置禁用回退（`llm_required=true`），不会把无 API 运行误报为 LLM 结果。

---

## 五、模型选择（评委可自主指定）

默认 `deepseek-v4-flash`（官方结论由它产生）。所有需要 LLM 的入口脚本均支持指定模型。

| 脚本         | PowerShell                                               | Linux/macOS                                                        |
| ------------ | -------------------------------------------------------- | ------------------------------------------------------------------ |
| 官方消融复现 | `.\scripts\reproduce_core.ps1 -Model deepseek-v4-pro`    | `DEEPSEEK_MODEL=deepseek-v4-pro bash scripts/reproduce_core.sh`    |
| 1 分钟演示   | `.\scripts\demo_one_minute.ps1 -Model deepseek-v4-pro`   | `DEEPSEEK_MODEL=deepseek-v4-pro bash scripts/demo_one_minute.sh`   |
| 开放探索     | `.\scripts\explore_open.ps1 -Model deepseek-v4-pro`      | `DEEPSEEK_MODEL=deepseek-v4-pro bash scripts/explore_open.sh`      |
| 模型验证     | `.\scripts\validate_deepseek_models.ps1 -Models "m1,m2"` | `DEEPSEEK_MODELS="m1,m2" bash scripts/validate_deepseek_models.sh` |

- **优先级**：脚本参数 > `DEEPSEEK_MODEL`/`DEEPSEEK_MODELS`（环境变量或 `.env`）> 配置默认值；
- **启动打印**：脚本第一行会显示本次模型与来源，如 `[Reproduce] Model: deepseek-v4-pro (explicit)` 或 `(config default)`；
- **目录分离**：指定模型时运行目录名自动追加模型后缀（如 `…_official_llm_lattice_112_deepseek-v4-pro`），不同模型互不覆盖；
- **三重可追溯**：控制台第一行、运行目录 `config.json` 的 `llm_model`、`trajectory.jsonl` 每条 `llm_exchange` 的 `model` 字段互相印证；
- **口径**：换模型生成的是独立新运行记录，用于跨模型复核，不会改动任何官方证据。

---

## 六、运行产物与结果解读

每次运行创建 `submission/runs/<UTC时间戳>_<run_name>[/_<model>]/`：

```text
├── config.json                  # 冻结配置（含 llm_model）
├── run_manifest.json            # 环境、模型和关键代码哈希
├── postprocess_manifest.json    # 派生总结代码与产物哈希（模式 B）
├── trajectory.jsonl             # 完整智能体轨迹
├── summary.json / summary.md    # 机器可读与人读结论
├── ablation_summary.png         # CFM/Exact-MC 射线指标与成本图
└── experiments/<experiment>/
    ├── diagnostics.json         # 智能体观测
    ├── metrics.json             # 原始 benchmark 指标
    ├── lattice_stage8_ultra.npz # 三种标量通量场
    ├── lattice_stage8_ultra.png # 可视化
    └── stdout.txt / stderr.txt  # 原始工具输出
```

`trajectory.jsonl` 记录 `run_started`、`llm_exchange`、`decision`、`agent_input`、`agent_output`、`tool_call`、`tool_result`、`environment_feedback`、`run_completed`（模式 B 另有 `summary_regenerated`）事件。

**探索完后如何选策略**：按预声明规则比较同预算下的 `ray_index`（FFT 方向集中度 × 残差 RMS，诊断代理量）与归一化 L1：

- 模式 B 的答案写在官方结论里：128 预算下选 `angular_refined`（较 position 低 43.5%）；要最干净参照选 `combined_refined`（较 coarse 低 57.3%），但承认 5.0% 学习算子残差；
- 模式 C 的答案写在 `summary.json` 的 `best_config` 字段，并附随机参照对比以排除种子波动。

---

## 七、算力与成本

- 已验证环境：Windows 10、Python 3.13.4、PyTorch 2.7.1+cu128、CUDA 12.8、NVIDIA GeForce GTX 1660 SUPER 6 GB；
- 官方运行实测：4 个 LLM 主链路实验约 109.6 秒 + 3 个随机参照约 100.5 秒；无 GPU 时自动退 CPU（24×24 演示仍可在数分钟内完成）；
- LLM 成本：V4-Flash 3 次决策共 1642 tokens，按 2026-09-03 官方价格上界估算低于 0.002 美元；复现时间受 GPU、首次内核编译、网络延迟与缓存状态影响。

---

## 八、提交前自检

复制粘贴即可（`setup_env` 创建的环境名固定为 `ssn`）：

```powershell
conda run -n ssn python scripts/verify_submission.py
```

[`verify_submission.py`](scripts/verify_submission.py) 校验必需文件、JSONL 事件完整性、产物引用、清单哈希、最新科学声明与常见 API 密钥模式。完整复赛材料索引见 [`submission/SUBMISSION_MANIFEST.md`](submission/SUBMISSION_MANIFEST.md)。

**常见问题**：

- *conda 找不到？* 安装 Miniconda，或 `-CondaExe` / `CONDA_EXE` 指定；
- *没有 GPU 能跑吗？* 能——冒烟与 24×24 演示在 CPU 上可完成，环境自动装 CPU 规格；
- *想换环境名？* `-EnvName` / `RAY_AGENT_ENV`；
- *密钥安全？* 见第四节；泄露过的密钥务必轮换。

---

## 九、已知边界

- 射线指标是 FFT 方向集中度与残差 RMS 的乘积，只是诊断代理量，不是通用物理可观测量；
- 正式因果消融使用一个固定种子；三个随机参考能揭示敏感性，但不是严格配对的多种子重复；
- 结果没有证明对所有几何、材料、源项、训练检查点或已有射线效应方法的普适优越性；
- 目前没有公开仓库 URL、冻结 commit/tag、参赛队号与作品名；这些必须在提交前由团队补齐。

---

## 十、环境、模型与数据

- 最小 Python 依赖见 `requirements.txt`；可复建的 Conda 描述见 `environment.yml`（GPU）与 `environment_cpu.yml`（CPU）；
- 边界与内部 CFM 检查点：`outputs/hpc_v2_models/boundary_900k_100ep/best.pt`、`outputs/hpc_v2_models/internal_900k_100ep/best.pt`（自产，MIT 再分发，训练管线见 [`01/02/08/09`](scripts/01_generate_boundary_data.py) 与 [`32_train_cfm_resumable.py`](scripts/32_train_cfm_resumable.py)）；
- benchmark 几何与材料由 [`gmc/benchmarks2d.py`](gmc/benchmarks2d.py) 程序化生成，不依赖外部测试数据集；
- 固定 Dense 比较场使用 `dense_n_mu=4, dense_n_phi=32`，是确定性参照，不被表述为连续方程真值；
- 正式智能体运行关闭额外全局 MC 图层（`mc_histories=0`）；原始现象图的全局 MC 只作为问题发现线索，不进入正式量化结论。

模型文件 SHA-256、解释器、GPU、CUDA 和关键源码摘要均写在官方运行的 `run_manifest.json` 中。

---

## 十一、许可与仓库结构

代码按 MIT License 发布；第三方依赖与自产模型权重的版权说明见 [`THIRD_PARTY_NOTICES.md`](THIRD_PARTY_NOTICES.md)。

```text
gmc/                     # 核心数值环境（CFM、Exact-MC、响应算子、benchmark 几何）
ray_agent/               # 智能体：环境封装、策略（含开放提议 OpenProposer）、日志、报告
scripts/
├── setup_env.ps1 / .sh          # 一键环境创建（自动选 CUDA/CPU 规格）
├── smoke_test.ps1 / .sh         # 离线冒烟（无需 API key）
├── demo_one_minute.ps1 / .sh    # 1 分钟 LLM 演示
├── reproduce_core.*             # 官方消融复现（模式 B）
├── explore_open.*               # 开放探索（模式 C，LLM 自主提议）
├── validate_deepseek_models.*   # 模型矩阵验证（模式 D）
├── verify_submission.py         # 提交前自检
├── run_ray_agent.py             # 模式 B 统一入口
├── run_open_exploration.py      # 模式 C 驱动
├── refinalize_ray_run.py        # 派生总结重建（不改动实验产物）
├── 01/02/08/09_*.py             # 边界/内部训练数据生成与 CFM 训练
├── 15_paper_scale_reproduce.sh / 16_slurm_paper_scale.sbatch  # 论文级复现管线
└── 30_stage8_ultra_benchmark.py / 32_train_cfm_resumable.py
configs/                 # 冻结配置（core_llm / demo / smoke / open_explore*）
submission/              # 全部提交材料：报告源稿、完整日志、参照系、证据台账
outputs/hpc_v2_models/   # 900k/120k 训练检查点（自产，MIT 再分发）
outputs/hpc_v2_data/     # 训练数据
tests/                   # 15 项物理/代数等价性测试
```

提交材料入口：[`submission/SUBMISSION_MANIFEST.md`](submission/SUBMISSION_MANIFEST.md)（材料索引）、[`submission/SCIENTIFIC_FINDING_AND_ENVIRONMENT.md`](submission/SCIENTIFIC_FINDING_AND_ENVIRONMENT.md)（科学发现与环境定义报告源稿）、[`submission/REFERENCE_BENCHMARK_DESIGN.md`](submission/REFERENCE_BENCHMARK_DESIGN.md)（参照系设计）、[`submission/EVIDENCE_LEDGER.md`](submission/EVIDENCE_LEDGER.md)（证据台账）、[`submission/TRACEABILITY.md`](submission/TRACEABILITY.md)（可追溯链）、[`submission/API_AND_SECURITY.md`](submission/API_AND_SECURITY.md)（API 与安全）。
