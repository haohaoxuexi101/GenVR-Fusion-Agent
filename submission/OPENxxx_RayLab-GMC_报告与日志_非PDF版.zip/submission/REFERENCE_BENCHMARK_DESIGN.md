# Reference Benchmark 设计

## 目标

比较一个因果假设驱动智能体与随机动作参考，而不是比较“是否能运行”。科学问题固定为：界面面位置压缩与角向欠分辨，哪个更能解释并缓解 GMC lattice 中的方向性伪影？

## 环境与动作空间

环境为 `scripts/30_stage8_ultra_benchmark.py`。因果动作池在运行前写入 `configs/ray_agent_core.json`：粗基线、只加密位置、只加密角向、联合加密。位置与角向单因素实验都为 128 个状态，构成等预算对照。停止规则是完成全部四个因果动作，不根据中间结果提前终止。

## Agent A：因果策略

- 顺序：baseline → position → angular → combined。
- 使用上一轮反馈生成下一轮决策理由。
- 所有动作都执行并报告；没有 best-of-N。
- 主要得分对象：等状态预算判别、联合缓解幅度、成本和残余误差。

## Agent B：随机参考

- 从剩余非基线动作中无放回随机选择三次。
- 每次种子不同，响应缓存隔离并使用 `--rebuild-response`。
- 目的不是证明随机策略必然更差，而是提供无反馈选择参考并暴露 seed variance。

## 固定项

二维 lattice、112×112、两份 CFM 检查点、float64、RK4=12、局部 CFM/Exact-MC 各 1000 样本、固定 Dense `n_mu=4,n_phi=32`、全局容差 `1e-10`、相同物理材料和源项。

## 指标

1. 主要诊断：CFM→fixed Dense spectral ray index。
2. 机制交叉检查：Exact-MC→fixed Dense spectral ray index。
3. 形状误差：归一化 L1、correlation、log10 RMSE。
4. 工程指标：状态数、构建/求解/子进程时间、求解残差。
5. 审计指标：事件类型完整性、产物可达性、配置/模型/代码哈希。

## 验收规则

- 完成所有声明的因果动作；
- 位置与角向比较必须状态数相同；
- 所有全局求解残差小于配置容差；
- 结论同时报告 CFM 和 Exact-MC，不能只选有利列；
- 随机参考单列，不混入因果估计；
- 任一失败、重试或 LLM 回退必须留在 JSONL；
- 不把 spectral ray index 表述为普适物理量。

## 已知不足

当前参考只含一次因果种子和三次非配对随机参考。正式论文级验证应为每个动作使用相同的一组多个种子，并报告均值、标准差与配对差分区间。
