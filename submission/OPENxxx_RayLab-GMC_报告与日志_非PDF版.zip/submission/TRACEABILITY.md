# 可追溯链

## 证据路径

```text
配置 configs/ray_agent_core.json
  + 关键源码/模型 SHA-256 run_manifest.json
  -> 智能体轨迹 trajectory.jsonl
  -> 每次命令 stdout/stderr + metrics.json + NPZ
  -> diagnostics.json
  -> summary.json / summary.md / ablation_summary.png
  -> postprocess_manifest.json
```

## 运行时冻结

`run_manifest.json` 记录创建时间、解释器绝对路径、Python、操作系统、Torch/CUDA/GPU、策略、选择规则以及配置、benchmark、核心响应模块和两份模型权重的字节数与 SHA-256。

## 轨迹模式

每行是独立 JSON，包含 `schema_version`、`run_id`、UTC 时间和 `event_type`。正式运行含：

- 1 个 `run_started`；
- 7 组 `decision/agent_input/agent_output/tool_call/tool_result/environment_feedback`；
- 1 个原始 `run_completed`；
- 派生总结更新后追加 `summary_regenerated`，而不是改写历史事件。

`tool_call.command` 是参数数组，避免 shell 展开歧义。`tool_result` 保存返回码、耗时、stdout/stderr 文件和有限尾部；完整输出仍留在实验目录。

## 后处理

科学结论文本和图是派生产物。`postprocess_manifest.json` 记录后处理脚本/报告模块与三份派生产物哈希。重新生成不会修改 `metrics.json`、NPZ 或 diagnostics，并会在轨迹末尾追加事件。

## 版本控制待办

当前工作目录没有 `.git` 元数据，因此无法填写 commit、tag 和公开仓库 URL。提交前必须：

1. 初始化或迁移到公开仓库；
2. 运行全量测试与 `scripts/verify_submission.py`；
3. 提交代码、配置、报告源稿和可接受体积的运行证据；
4. 创建不可变 tag（建议 `open-final-v1`）；
5. 在 `SUBMISSION_MANIFEST.md` 填入仓库 URL、commit 和 tag；
6. 若大权重不能进 Git，发布带 SHA-256 的下载地址或 Git LFS，并验证一键脚本。
