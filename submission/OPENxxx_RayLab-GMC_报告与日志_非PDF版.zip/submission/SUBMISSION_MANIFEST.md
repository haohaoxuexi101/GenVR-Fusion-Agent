# 复赛提交材料索引

规则来源：`复赛提交说明.pdf`。本目录按其六类交付物组织。用户要求本阶段暂不制作 PPT 和 PDF，因此相应项保留为明确待办。

| 要求                          | 当前交付                                                                           | 状态                              |
| ----------------------------- | ---------------------------------------------------------------------------------- | --------------------------------- |
| 1. 项目展示 PPT               | 未生成                                                                             | 待办（用户暂缓）                  |
| 2. 科学发现与环境定义报告 PDF | `SCIENTIFIC_FINDING_AND_ENVIRONMENT.md` 源稿                                       | 源稿完成，PDF 暂缓                |
| 3. 最小可运行环境             | `environment.yml`、`requirements.txt`、`configs/`、`scripts/smoke_test.*`          | 完成                              |
| 4. 完整 JSON/JSONL 日志       | `runs/official_final/trajectory.jsonl`、manifest、每实验 stdout/stderr/metrics/NPZ | 完成                              |
| 5. Reference Benchmark        | `REFERENCE_BENCHMARK_DESIGN.md`、因果/随机结果写入 `summary.json`                  | 完成（多种子配对为局限）          |
| 6. 公开代码仓库与 README      | 根目录 `README.md`、LICENSE、CITATION、测试                                        | 本地完成；公开 URL/tag 待团队补齐 |

## 核心证据入口

- 科学结论：`runs/official_final/summary.md`
- 机器可读结果：`runs/official_final/summary.json`
- 完整轨迹：`runs/official_final/trajectory.jsonl`
- 环境和输入哈希：`runs/official_final/run_manifest.json`
- 派生产物哈希：`runs/official_final/postprocess_manifest.json`
- 总览图：`runs/official_final/ablation_summary.png`
- 文献/内部证据边界：`EVIDENCE_LEDGER.md`
- 可追溯说明：`TRACEABILITY.md`
- API 安全：`API_AND_SECURITY.md`

## 提交前必须填写

- 参赛队号：`OPENxxx`
- 作品名（建议）：`RayLab-GMC：GMC 响应算子射线伪影因果审计智能体`
- 公开仓库 URL：待填
- 冻结 commit：待填
- 冻结 tag：待填
- 负责人/成员署名：待填
- 两份模型权重的训练数据来源、权利人与再分发许可：已完成（自产数据，见 `THIRD_PARTY_NOTICES.md`）

## 最终文件名建议

- PPT：`OPENxxx_RayLab-GMC_项目展示.pptx`
- 报告：`OPENxxx_RayLab-GMC_科学发现与环境定义报告.pdf`
- 报告与日志包：`OPENxxx_RayLab-GMC_报告与日志.zip`

不要在这些文件中包含 API key、访问令牌或未确认可再分发的数据/权重。

## 当前非 PDF 草案包

`OPENxxx_RayLab-GMC_报告与日志_非PDF版.zip` 已包含上述 Markdown 源稿、环境说明和 `official_final` 完整日志/产物。`bundle_manifest.json` 给出包内文件哈希。它不是最终提交包：替换队号后，还必须加入规定的 PPT 和报告 PDF。
