# Evidence Ledger

本台账把“外部先验”与“本项目实测”分开。外部文献只用于界定问题与已有路线，不替代本项目数值证据。

## 外部证据

| ID | 来源 | 可支持的陈述 | 不能支持的陈述 | 状态 |
|---|---|---|---|---|
| E1 | K. D. Lathrop, *Ray Effects in Discrete Ordinates Equations*, Nuclear Science and Engineering 32 (1968), DOI [10.13182/NSE68-4](https://doi.org/10.13182/NSE68-4) | 离散角变量会产生异常方向伪影；增加角向阶数是可能但有成本的补救 | 不能直接证明 GMC 的具体伪影机制 | 已核对出版页面 |
| E2 | K. D. Lathrop, *Remedies for Ray Effects*, Nuclear Science and Engineering 45 (1971), DOI [10.13182/NSE45-03-255](https://doi.org/10.13182/NSE45-03-255) | 增加/选择方向和更改离散形式属于经典补救路线 | 不能证明本项目联合加密是最优方案 | 已核对出版页面 |
| E3 | T. Camminady et al., *Ray effect mitigation for the discrete ordinates method through quadrature rotation*, JCP 382 (2019), DOI [10.1016/j.jcp.2019.01.016](https://doi.org/10.1016/j.jcp.2019.01.016) | 角向集合旋转是已发表的缓解方向，因此后续可测试去相干机制 | 不能据此声称本项目实现了 quadrature rotation | DOI/书目信息已核对 |
| E4 | L. M. Gomes and P. N. Stevens, *Use of Monte Carlo Procedures to Estimate First and Second Collision Sources for Discrete Ordinates Transport Codes*, NSE 114 (1993), DOI [10.13182/NSE93-A24036](https://doi.org/10.13182/NSE93-A24036) | MC collision source 与离散纵标混合是已有的射线效应缓解思路 | 不能推出有限状态的 MC 响应算子必然无伪影 | 已核对 ANS 出版页面 |

## 内部证据

| ID | 证据 | 支持的陈述 | 限制 |
|---|---|---|---|
| I1 | `official_llm/experiments/coarse/` | 粗状态 CFM 和 Exact-MC 相对固定 Dense 都存在方向性残差 | 单种子、有限样本 |
| I7 | `api_validation/deepseek_model_matrix.json` | V4-Flash 与 V4-Pro 都能读取同一反馈并产生白名单内动作；两模型选择不同 | 仅一次同反馈 API 探针，不代表统计稳定性 |
| I2 | position 与 angular 的 128 状态对照 | 角向分配的 CFM ray index 比位置分配低 43.5% | 只对当前配置成立 |
| I3 | combined Exact-MC vs Dense | 联合加密相对粗基线 ray index 降低 57.3% | Dense 不是连续真值 |
| I4 | combined CFM vs Exact-MC | 联合加密后仍有 5.0% normalized L1 | 不能仅由该指标定位网络误差来源 |
| I5 | `cfm_residual` 与 oracle residual | 全局线性求解已达到约 `1e-10` 量级 | 不排除其他离散/采样误差 |
| I6 | 三次 random reference | 结果存在 seed sensitivity | 非配对重复，不能估计严格置信区间 |

## 声明级别

- 已支持：当前算例固定预算下角向资源优先级、联合加密的局部 Exact-MC 缓解、CFM 残差仍存在。
- 待验证：旋转/抖动角向集合能否降低跨单元相干、守恒正则能否减少 CFM 残差、多碰撞混合能否改善未碰撞束。
- 禁止表述：首次发现射线效应、普适消除 GMC 射线效应、全面优于所有已有方法。
